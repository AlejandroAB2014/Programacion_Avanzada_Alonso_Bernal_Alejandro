/* Empleado.h - Declara la clase Empleado*/

#ifndef EMPLEADO_H
#define EMPLEADO_H

class Empleado{
public: 

	//Constructor
	Empleado(const char *, const char* const);
	~Empleado();

	const char *getPrimerNombre() const; //Devuelve el primer nombre 
	const char *getApellidoPaterno() const; //Devuelve el apellido paterno

	static int getCuenta(); //Devuelve el numero de objetos instanciados

private:
	char *primerNombre;
	char *apellidoPaterno;

	//datos static 
	static int cuenta; 
	
}; //end class empleado

#endif /* EMPLEADO_H */
