#include <iostream> 
using std::cout;
using std::endl;

#include "Empleado.h"

int main(){
	Empleado *e1Ptr = new Empleado("Susan", "Baker");
	Empleado *e2Ptr = new Empleado("Richard", "Jones");
    cout<<"El numero de empleados antes de instanciar cualquier objeto es " <<Empleado::getCuenta()<<endl;
    system("PAUSE");
	return 0;
	
} 
