/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ObjProject;

import java.util.Scanner;

/**
 *
 * @author Sala5
 */
public class ObjProject {

    Scanner scan = new Scanner(System.in);
    int enteroPVTOTE;
    String stringPVTOTE;
public static void main(String[] args) {
    
    Scanner Scan= new Scanner(System.in);
    System.out.println("Teclee un valor entero");
    ObjProject TO = new ObjProject();
    TO.enteroPVTOTE = TO.scan.nextInt();
    System.out.println("El entero tecleado fue: " + TO.enteroPVTOTE );
    TO.stringPVTOTE = Scan.next();
    System.out.println("La cadena tecleada fue: " + TO.stringPVTOTE );
}
    
}
//clases objetos metodos atributos 
