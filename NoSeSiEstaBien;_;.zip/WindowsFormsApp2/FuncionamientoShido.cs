﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1v2 : Form
    {
        public String[,] FA;
        public Form1v2()
        {
            InitializeComponent();
            AsignarDatosTabla();
            //inic_FA();
        }
        public void inic_FA()
        {
            FA = new String[4,8]; 
            object valorCelda;
            int index,num,den;
            for (int i = 0; i <= 3; i++)
            {
                for(int j = 1; j <= 6; j++)
                {
                    valorCelda= dataGridView1.Rows[i].Cells[j].Value;
                    index = valorCelda.ToString().IndexOf("/");
                    num = Convert.ToInt32(valorCelda.ToString().Substring(0, index));
                    den = Convert.ToInt32(valorCelda.ToString().Substring(index + 1));
                    //FA[i,j] = (float)num / (float)den;
                    FA[i, j] = num.ToString() + "/" + den.ToString();
                }
            }
        }//end inic_FA()
         /*  private void inic1_FA()
           {
               FA = new float[4, 7];
               object valorCelda;
               for (int i = 0; i <= 3; i++)
               {
                   for (int j = 1; j <= 6; j++)
                   {
                       valorCelda = dataGridView1.Rows[i].Cells[j].Value;

                       FA[i, j] = (float)Convert.ToDouble(valorCelda.ToString());
                   }
               }
           }
           */
        public string decToFrac(float num) {

            float a, b;
            float aux;
            a = 1;
            b = 1;
            aux = 1;
            while (!(aux == num)){
                aux = a / b;
                if (aux < num)
                {
                    a++;
                }
                else if (aux > num) {
                    a--;
                    b++;
                }
            }
            string valor = a.ToString() +"/"+ b.ToString();
            return valor; 
        }

        private void AsignarDatosTabla()
        {
            object[] fila0 = { "1/1", "-3/1", "-5/1", "0/1", "0/1", "0/1", "0/1",""};
            object[] fila1 = { "x3", "1/1", "0/1", "1/1", "0/1", "0/1", "4/1","" };
            object[] fila2 = { "x4", "0/1", "2/1", "0/1", "1/1", "0/1", "12/1","" };
            object[] fila3 = { "x5", "3/1", "2/1", "0/1", "0/1", "1/1", "18/1","" };
            //object[] fila0 = { "1.0", "-3.0", "-5.0", "0.0", "0.0", "0.0", "0.0", "" };
            //object[] fila1 = { "x3", "1.0", "0.0", "1.0", "0.0", "0.0", "4.0", "" };
            //object[] fila2 = { "x4", "0.0", "2.0", "0.0", "1.0", "0.0", "12.0", "" };
            //object[] fila3 = { "x5", "3.0", "2.0", "0.0", "0.0", "1.0", "18.0", "" };
            dataGridView1.Rows.Add(fila0);
            dataGridView1.Rows.Add(fila1);
            dataGridView1.Rows.Add(fila2);
            dataGridView1.Rows.Add(fila3);
        }

        private void Form1v2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int colPivote = Convert.ToInt32(textBox1.Text);
            int colDisponibilidad = 6;
            int num, den, index;
            object valorCelda;
            Rac RacNum = new Rac(), RacDen = new Rac(), RacQ = new Rac();
            float qRac;
            /*
            for (int i = 1; i <= 3; i++)
            {
                valorCelda = dataGridView1.Rows[i].Cells[colDisponibilidad].Value;
                index = valorCelda.ToString().IndexOf("/");
                num = Convert.ToInt32(valorCelda.ToString().Substring(0, index));
                den = Convert.ToInt32(valorCelda.ToString().Substring(index + 1));
                RacNum.set_n(num);
                RacNum.set_d(den);
                valorCelda = dataGridView1.Rows[i].Cells[colPivote].Value;
                index = valorCelda.ToString().IndexOf("/");
                num = Convert.ToInt32(valorCelda.ToString().Substring(0, index));
                den = Convert.ToInt32(valorCelda.ToString().Substring(index + 1));
                RacDen.set_n(num);
                RacDen.set_d(den);
                if ((RacDen.get_n() != 0) && (RacDen.get_d() != 0))
                {
                    RacQ = RacNum / RacDen;
                    num = RacQ.get_n(); den = RacQ.get_d();
                    qRac = (float)num / (float)den;
                    //dataGridView1.Rows[i].Cells[colDisponibilidad + 1].Value = qRac.ToString();
                }
            }
            */
            float qValor, Num, Den, NumX, NumY, DenX, DenY;
            for (int i = 0; i <= 3; i++)
            {
                dataGridView1.Rows[i].Cells[6 + 1].Value = "";
            }
            for (int i = 1; i <= 3; i++)
            {
                valorCelda = dataGridView1.Rows[i].Cells[colDisponibilidad].Value;
                if (valorCelda.ToString().Contains("*"))
                {
                    int indexMultI = valorCelda.ToString().IndexOf("(");
                    int indexMultF = valorCelda.ToString().IndexOf(")");
                    int MultLong = indexMultF - indexMultI;
                    index = valorCelda.ToString().IndexOf("/");
                    int indexPlus = valorCelda.ToString().IndexOf("+");
                    NumX = (float)Convert.ToDouble(valorCelda.ToString().Substring(0, index));
                    DenX = (float)Convert.ToDouble(valorCelda.ToString().Substring(index + 1, 1));
                    Num = NumX / DenX;
                    Den = (float)Convert.ToDouble(valorCelda.ToString().Substring(indexMultI+1, MultLong-1));
                    //Problema existe aqui, no se puede transformar una multiplicacion de tipo String a un valor de tipo Float.
                    //Encontrar manera de leer numero a numero 
                    String q = Num.ToString() + "/" + Den.ToString();
                    //qValor = Num / Den;
                    dataGridView1.Rows[i].Cells[colDisponibilidad + 1].Value = q.ToString();
                }
                else
                {
                    index = valorCelda.ToString().IndexOf("/");
                    NumX = (float)Convert.ToDouble(valorCelda.ToString().Substring(0, index));
                    DenX = (float)Convert.ToDouble(valorCelda.ToString().Substring(index + 1));
                    Num = NumX / DenX;
                    valorCelda = dataGridView1.Rows[i].Cells[colPivote].Value;
                    index = valorCelda.ToString().IndexOf("/");
                    NumY = (float)Convert.ToDouble(valorCelda.ToString().Substring(0, index));
                    DenY = (float)Convert.ToDouble(valorCelda.ToString().Substring(index + 1));
                    Den = NumY / DenY;
                    //valorCelda = dataGridView1.Rows[i].Cells[colDisponibilidad].Value;
                    //Num = (float)Convert.ToDouble(valorCelda.ToString());
                    //valorCelda = dataGridView1.Rows[i].Cells[colPivote].Value;
                    //Den=(float)Convert.ToDouble(valorCelda.ToString());
                    if (Den != 0)
                    {
                        String q = Num.ToString() + "/" + Den.ToString();
                        qValor = Num / Den;
                        dataGridView1.Rows[i].Cells[colDisponibilidad + 1].Value = q.ToString();

                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int colPivote = Convert.ToInt32(textBox1.Text);
            String[] headers = {"z","x1","x2","x3","x4","x5",};
            textBox4.Text = headers[colPivote];
            textBox3.Text = dataGridView1.Rows[Convert.ToInt32(textBox2.Text)].Cells[0].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int fp, cp;     //fila pivote, columna pivote
            float factor;
            String[] headers = { "z", "x1", "x2", "x3", "x4", "x5", };
            fp = Convert.ToInt32(textBox2.Text);
            cp = Convert.ToInt32(textBox1.Text);
            dataGridView1.Rows[fp].Cells[0].Value = headers[cp];
            inic_FA();
            int index = FA[fp, cp].IndexOf("/");
            float num = Convert.ToInt32(FA[fp, cp].Substring(0, index));
            float den = Convert.ToInt32(FA[fp, cp].Substring(index + 1));
            float factorD = num / den;
            //factor = 1/FA[fp,cp];
            factor = 1 / factorD;
            for (int j = 1; j <= 6; j++)
            {
                index = FA[fp, j].IndexOf("/");
                num = Convert.ToInt32(FA[fp, j].Substring(0, index));
                den = Convert.ToInt32(FA[fp, j].Substring(index + 1));
                float FA_fpj = num / den;
                //FA[fp, j] = factor * FA[fp, j];
                //FA[fp, j] = FA_fpj.ToString() + "/"+ factor.ToString() ;
                FA[fp, j] = decToFrac((FA_fpj * factor));
                dataGridView1.Rows[fp].Cells[j].Value = FA[fp, j];
            }
            for (int i = 0; i <= 3; i++)
            {
                if (i != fp)
                {
                    index = FA[i, cp].IndexOf("/");
                    num = Convert.ToInt32(FA[i, cp].Substring(0, index));
                    den = Convert.ToInt32(FA[i, cp].Substring(index + 1));
                    float FA_icp = num / den;
                    //factor = -FA[i, cp];
                    factor = -FA_icp;
                    for (int j = 1; j <= 6; j++)
                    {
                        //FA[i, j] = FA[i, j] + "+" + factor.ToString() +"*"+ FA[fp, j];
                        //float FA_fpj = (float)Convert.ToDouble(FA[fp, j]);
                        index = FA[fp, j].IndexOf("/");
                        int numx = Convert.ToInt32(FA[fp, j].Substring(0, index));
                        int deny = Convert.ToInt32(FA[fp, j].Substring(index + 1));
                        float numxyz = numx * factor;
                        string seg;
                        if (numxyz == 0)
                        {
                           seg = "0/1";
                           //seg = numxyz.ToString() + "/" + deny.ToString();
                        }
                        else if (numxyz < 0) {
                            seg = (numxyz/deny).ToString(); 
                        }
                        else
                        {
                            seg = numxyz.ToString() + "/" + deny.ToString();
                        }
                        string value;
                        int indexone = FA[i, j].IndexOf("/");
                        int indextwo = seg.IndexOf("/");
                        if (indextwo != -1) { 
                            int numone = Convert.ToInt32(FA[i, j].Substring(0, indexone));
                            int denone = Convert.ToInt32(FA[i, j].Substring(indexone + 1));
                            int numtwo = Convert.ToInt32(seg.Substring(0, indextwo));
                            int dentwo = Convert.ToInt32(seg.Substring(indextwo + 1));
                            value = (numone + numtwo).ToString() + "/" + (denone*dentwo).ToString();
                        } else {
                            int numone = Convert.ToInt32(FA[i, j].Substring(0, indexone));
                            int denone = Convert.ToInt32(FA[i, j].Substring(indexone + 1));
                            float numtwo = (float)Convert.ToDouble(seg);
                            int dentwo = 1;
                            value = (numone + numtwo).ToString() + "/" + (denone * dentwo).ToString();
                        }
                        //FA[i, j] =  FA[i, j] + " + "+"(" + seg+ ")";
                        FA[i, j] = value; 
                        //FA[i, j] = FA[i, j] + " + " + "(" + decToFrac((FA_fpj * factor)) + ")";
                        dataGridView1.Rows[i].Cells[j].Value = FA[i, j].ToString();
                    }
                }
            }
            for(int i = 0; i <= 3; i++)
            {
                dataGridView1.Rows[i].Cells[6 + 1].Value = "";
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }//end button3_Click(object sender, EventArgs e)

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }//end class Form1v2
}//end namespace WindowsFormsApp2
