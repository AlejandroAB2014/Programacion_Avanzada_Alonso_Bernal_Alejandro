#include <cstdlib>
#include <iostream>

using namespace std;
#define ARCHIVO.TXT c:/Users/Sala5/archivo.txt //respaldazo de datos ; _; 
int main(int argc, char *argv[])
{
    system("PAUSE");
    cout<<"Hola Mundo"<<endl; 
    system("PAUSE");
    return EXIT_SUCCESS;
}
